from setuptools import find_packages, setup

setup(
    name="spentalkux",
    version="13.37",
    description="I dare you to import this",
    packages=find_packages(),
    install_requires=[""],
)
